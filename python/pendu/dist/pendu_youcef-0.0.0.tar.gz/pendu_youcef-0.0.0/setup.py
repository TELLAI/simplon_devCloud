from setuptools import setup

setup(
    name = "pendu_youcef",
    entry_points  =  { 
        'console_scripts' :  [ 'pendu_youcef = jeu2' ], 
    }
)
